<?php
    $contactName = $_POST["ContactName"];
    $contactEmail = $_POST["ContactEmail"];
    $contactmessage = $_POST["message"];

    $sql_connection = mysql_connect("localhost", "root", "root");

    mysql_select_db("MyRadContactForm", $sql_connection);

    

    $sql = "INSERT INTO 
            VALUES (
                '$contactName',
                '$contactEmail',
                '$contactLeastFavoriteColor',
                NOW()
            )"

    mysql_query($sql, $sql_connection);

    mysql_close($sql_connection);
?>
