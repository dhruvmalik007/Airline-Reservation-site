<div class="footer" style="clear:both">
		
	</div>



</body>

</html>

<?php
    if(isset($connection)){
		//mysqli_close($connection);
    }
?>