# Airline-Reservation-System
An airline reservation system with both Database and GUI

Database is developed using MySQL Sever and GUI components include utilization of PHP, JavaScript (jQuery), HTML5, CSS3-Boostrap
